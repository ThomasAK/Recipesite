package banana.controller;

import banana.entity.BananaData;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;


@RequestMapping("/banana")
@RestController
public class BananaController {
    @GetMapping
    public BananaData index(){
        return new BananaData(44,"bananas",true, Arrays.asList("taco", "waffle", "banana"),
                new BananaData(44,"bananas",true, Arrays.asList("taco","waffle","banana"), null ) );
    }
}
