package banana.entity;

import java.util.List;

public class BananaData {
    private int waffle;
    private String tacos;
    private boolean pancakes;
    private List<String> charly;
    private BananaData bananas;

    public BananaData(int waffle, String tacos, boolean pancakes, List<String> charly, BananaData bananas) {
        this.waffle = waffle;
        this.tacos = tacos;
        this.pancakes = pancakes;
        this.charly = charly;
        this.bananas = bananas;
    }

    public int getWaffle() {
        return waffle;
    }

    public void setWaffle(int waffle) {
        this.waffle = waffle;
    }

    public String getTacos() {
        return tacos;
    }

    public void setTacos(String tacos) {
        this.tacos = tacos;
    }

    public boolean isPancakes() {
        return pancakes;
    }

    public void setPancakes(boolean pancakes) {
        this.pancakes = pancakes;
    }

    public List<String> getCharly() {
        return charly;
    }

    public void setCharly(List<String> charly) {
        this.charly = charly;
    }

    public BananaData getBananas() {
        return bananas;
    }

    public void setBananas(BananaData bananas) {
        this.bananas = bananas;
    }
}
